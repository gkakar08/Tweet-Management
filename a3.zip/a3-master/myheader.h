#include <time.h>
#include <ctype.h>
int getOption(void);

